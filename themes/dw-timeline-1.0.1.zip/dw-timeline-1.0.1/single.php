<?php global $content_width; $content_width = 750; ?>
<?php get_template_part('templates/content', 'single'); ?>