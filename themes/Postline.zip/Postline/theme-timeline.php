<?php
// Ajax Actions
add_action( 'wp_ajax_timeline_add_element', 'themify_timeline_add_element_ajaxify', 10 );
add_action('wp_ajax_nopriv_timeline_add_element', 'themify_timeline_add_element_ajaxify');
function themify_timeline_add_element_ajaxify() {

	if ( ! wp_verify_nonce( $_POST['timeline_load_nonce'], 'timeline_load_nonce' ) ) die(-1);

	$post_ids = is_array($_POST['post_ids']) ? $_POST['post_ids'] : array() ;
	$posts_page = $_POST['posts_page'];
	$args = array(
		'post__in' => $post_ids,
		'posts_per_page' => $posts_page
	);
	
	if( count($post_ids > 0) ) {
		themify_timeline_loop_element($args);
	}
	
	die();
}

function themify_timeline_loop_element($args) {
	global $wpdb, $themify;

	// set image width timeline
	$themify->width = apply_filters( 'timeline_loaded_element_image_size', 365 );

	// The Query
	$the_query = new WP_Query( $args );

	// The Loop
	while ( $the_query->have_posts() ) :
		$the_query->the_post(); ?>

		<?php themify_post_before(); //hook ?>
		<article id="post-<?php the_ID(); ?>" <?php post_class("post clearfix"); ?>>
		<?php themify_post_start(); //hook ?>
		        
			<div class="post-inner">
			<?php if(is_search()): ?>
				<?php get_template_part( 'includes/loop' , 'search'); ?>
			<?php else: ?>
				<?php get_template_part( 'includes/loop' , 'index'); ?>
			<?php endif; ?>
			</div>
			<!-- /.post-inner -->
		            
		<?php themify_post_end(); //hook ?>
		</article>
		<!-- /.post -->
		<?php themify_post_after(); //hook ?>

	<?php
	endwhile;
	wp_reset_postdata();

}
?>