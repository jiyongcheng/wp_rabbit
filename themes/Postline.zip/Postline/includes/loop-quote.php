<?php
/** Themify Default Variables
 *  @var object */
global $themify; ?>

<?php $quote_author = themify_get('quote_author'); ?>
<?php $quote_author_link = themify_get('quote_author_link'); ?>

<!-- quote-content -->
<div class="quote-content">
	
	<?php if($themify->display_content == 'excerpt'): ?>
	
		<?php the_excerpt(); ?>
	
	<?php elseif($themify->display_content == 'none'): ?>
	
	<?php else: ?>
	
		<?php the_content(themify_check('setting-default_more_text')? themify_get('setting-default_more_text') : __('More &rarr;', 'themify')); ?>
	
	<?php endif; ?>
</div>
<!-- /quote-content -->

<!-- quote-author -->
<p class="quote-author">
	&#8212; <?php if($quote_author_link != '') { echo '<a href="'.$quote_author_link.'">'; } ?><?php echo $quote_author; ?><?php if($quote_author_link != '') { echo '</a>'; } ?>
</p>
<!-- /quote-author -->