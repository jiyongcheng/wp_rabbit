<?php if(!is_single()) { global $more; $more = 0; } //enable more link ?>

<?php
/** Themify Default Variables
 @var object */
	global $themify; ?>

		<!-- Title, post icon, post date -->
		<span class="post-icon"></span>
		<?php if($themify->hide_date != "yes"): ?>
			<time datetime="<?php the_time('o-m-d') ?>" class="post-date" pubdate>
				<span><?php the_time(apply_filters('themify_loop_date', 'M j, Y')) ?></span>
			</time>
		<?php endif; //post date ?>
		
		<?php if($themify->hide_title != "yes"): ?>
			<?php themify_before_post_title(); // Hook ?>
			<?php if($themify->unlink_title == "yes"): ?>
				<h1 class="post-title"><?php the_title(); ?></h1>
			<?php else: ?>
				<h1 class="post-title"><a href="<?php echo $themify->link_post_format(); ?>"><?php the_title(); ?></a></h1>
			<?php endif; //unlink post title ?>
			<?php themify_after_post_title(); // Hook ?>
		<?php endif; //post title ?>
		<!-- / Title, post icon, post date -->
	
		<?php get_template_part('includes/loop-' . $themify->get_format_template()); ?>

		<div class="post-dot"></div><!-- /post-dot -->
		<div class="post-arrow"></div><!-- /post-arrow -->