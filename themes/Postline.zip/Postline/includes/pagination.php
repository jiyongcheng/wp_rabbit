<?php
/**
 * Creates numbered pagination or displays button for infinite scroll based on user selection
 * @since 1.0.0
 */
	if( 'infinite' == themify_get('setting-more_posts') || '' == themify_get('setting-more_posts') ){
		global $wp_query, $themify;
		$total_pages = $wp_query->max_num_pages;
		$current_page = (get_query_var('paged')) ? get_query_var('paged') : 1;

		if( $total_pages > $current_page ){
			if($themify->query_category != ""){
				//If it's a Query Category page, set the number of total pages
				echo '<script type="text/javascript">var qp_max_pages = ' . $total_pages . '</script>';
			}

			// if is_home and timeline or page and timeline apply different load more button
			if( ('timeline' == themify_get('setting-default_post_layout') && ($themify->post_layout == 'timeline'))
			|| ( 'timeline' == $themify->post_layout && is_page() ) ){
				// do nothing
				// timeline pagination is different than regular so it's need to always show outside total pages
			}
			else{
				echo '<div id="general-load-more"><p id="load-more"><a href="' . next_posts( $total_pages, false ) . '">' . __('Load More', '') . '</a></p></div>';
			}
			
		}

		?>

		<?php if( ('timeline' == themify_get('setting-default_post_layout') && ($themify->post_layout == 'timeline'))
			|| ( 'timeline' == $themify->post_layout && is_page() ) ): ?>
				<div id="timeline-load-more">
					<p id="load-more">
						<a href="#"><?php _e('Load more', 'themify') ?></a>
					</p>
				</div>
		<?php endif; ?>
		
		<?php

	} else {
		themify_pagenav();
	}
	
?>