jQuery(window).load(function(){
	jQuery('.shortcode.slider, .shortcode.post-slider').css({
		'height': 'auto', 
		'visibility': 'visible'	}); 
});

