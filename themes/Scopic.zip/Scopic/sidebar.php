<?php if ( is_active_sidebar( 'st_sidebar_primary' ) ) { ?>

<!-- #sidebar -->
	<aside id="sidebar" role="complementary">   
    
		<?php dynamic_sidebar( 'st_sidebar_primary' );?>
        
	</aside>
<!-- /#sidebar -->

<?php } ?>