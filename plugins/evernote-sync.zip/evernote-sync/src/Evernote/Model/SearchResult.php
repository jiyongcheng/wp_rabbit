<?php

namespace Evernote\Model;

class SearchResult
{
    public $guid;

    public $type;

    public $title;

    public $created;

    public $updated;
} 