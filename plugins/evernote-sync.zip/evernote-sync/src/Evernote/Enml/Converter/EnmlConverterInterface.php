<?php

namespace Evernote\Enml\Converter;

interface EnmlConverterInterface
{
    public function convertToEnml($content);
} 