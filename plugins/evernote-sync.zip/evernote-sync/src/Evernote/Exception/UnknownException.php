<?php

namespace Evernote\Exception;

class UnknownException extends \Exception
{

} 