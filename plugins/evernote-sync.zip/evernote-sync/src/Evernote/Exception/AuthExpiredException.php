<?php

namespace Evernote\Exception;

class AuthExpiredException extends \Exception
{
    
} 