<?php

namespace Evernote\Exception;

class BadDataFormatException extends \Exception
{

} 