<?php

namespace Evernote\Exception;

class TooManyException extends \Exception
{
    
} 