<?php

namespace Evernote\Exception;

class InternalErrorException extends \Exception
{

} 