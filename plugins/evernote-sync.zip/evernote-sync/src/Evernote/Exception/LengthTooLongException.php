<?php

namespace Evernote\Exception;

class LengthTooLongException extends \Exception
{
    
} 