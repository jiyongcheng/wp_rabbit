<?php

namespace Evernote\Exception;

class TooFewException extends \Exception
{
    
} 