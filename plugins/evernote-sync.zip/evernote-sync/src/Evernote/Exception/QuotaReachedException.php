<?php

namespace Evernote\Exception;

class QuotaReachedException extends \Exception
{
    
} 