<?php

namespace Evernote\Exception;

class LengthTooShortException extends \Exception
{
    
} 