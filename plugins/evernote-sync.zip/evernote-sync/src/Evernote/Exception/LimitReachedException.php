<?php

namespace Evernote\Exception;

class LimitReachedException extends \Exception
{

} 