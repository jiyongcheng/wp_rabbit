<?php

namespace Evernote\Exception;

class InvalidAuthException extends \Exception
{
    
} 