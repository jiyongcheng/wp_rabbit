<?php

namespace Evernote\Exception;

class RateLimitReachedException extends \Exception
{
    
} 