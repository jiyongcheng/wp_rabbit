<?php

namespace Evernote\Exception;

class PermissionDeniedException extends \Exception
{

} 