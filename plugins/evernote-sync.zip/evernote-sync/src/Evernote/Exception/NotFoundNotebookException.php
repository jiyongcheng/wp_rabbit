<?php

namespace Evernote\Exception;

class NotFoundNotebookException extends \Exception
{

} 