<?php

namespace Evernote\Exception;

class DataConflictException extends \Exception
{
    
} 